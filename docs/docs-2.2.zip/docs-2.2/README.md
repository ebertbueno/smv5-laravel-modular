# Introduction

Pingpong Sky is a PHP component made specifically for Laravel. Pingpong Sky includes some ready-made components such as Modules, Menus and Widgets.

# Features

- Menus
- Modules
- Widget
- Shortcode
- Presenters
- Themes
- Trusty
- Generators

# License

This package is open-sourced software licensed under [The BSD 3-Clause License](http://opensource.org/licenses/BSD-3-Clause)
